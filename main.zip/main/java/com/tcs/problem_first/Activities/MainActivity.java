package com.tcs.problem_first.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.tcs.problem_first.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText user;
    EditText pass;
    Button  logBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        user=(EditText)findViewById(R.id.ev_username);
        pass=(EditText)findViewById(R.id.ev_password);
        logBtn=(Button)findViewById(R.id.b_logIn);
        logBtn.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.b_logIn){
            if(user.getText().toString().isEmpty()){
                Toast.makeText(getApplicationContext(),"Enter user name!!",Toast.LENGTH_SHORT).show();
            }
            else if(pass.getText().toString().isEmpty()){
                Toast.makeText(getApplicationContext(),"Enter password!!",Toast.LENGTH_SHORT).show();
            }
            else if(!pass.getText().toString().equals("tcs")){
                Toast.makeText(getApplicationContext(),"Incorrect credentials!!",Toast.LENGTH_SHORT).show();
                pass.setText("");
            }
            else{
                Toast.makeText(getApplicationContext(),"Logging in!!",Toast.LENGTH_SHORT).show();
                Intent loggingIntent=new Intent(this,HomeScreen.class);
                loggingIntent.putExtra("name",user.getText().toString());
                startActivity(loggingIntent);
            }
        }
    }
}
