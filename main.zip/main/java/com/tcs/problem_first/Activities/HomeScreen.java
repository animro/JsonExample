package com.tcs.problem_first.Activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.tcs.problem_first.Fragments.AddNewsFragment;
import com.tcs.problem_first.Fragments.NewsDetailsFragment;
import com.tcs.problem_first.Fragments.ViewNewsFragment;
import com.tcs.problem_first.MyCallBackInterface;
import com.tcs.problem_first.R;
import com.tcs.problem_first.Utils.utils;

public class HomeScreen extends AppCompatActivity implements MyCallBackInterface{


    private static final int RESULT_LOAD_IMAGE =1;
    Toolbar toolbar;
    DrawerLayout drawerLayout;
    TextView userName;
    public static final int ADD_NEWS=0;
    public static final int VIEW_NEWS=1;
    public static final int LOG_OUT=2;
    public static final int NEWS_PIC_CHANGE=1;
    public static final int PROF_PIC_CHANGE=0;
    public static int picValue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        toolbar=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        Intent loggingIntent=getIntent();
        userName=(TextView)findViewById(R.id.tv_name);

        if(loggingIntent!=null){
            String user=loggingIntent.getStringExtra("name");
            userName.setText(user);}

        drawerLayout=(DrawerLayout)findViewById(R.id.drawer_layout_id);
        ActionBarDrawerToggle actionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open_drawer,R.string.close_drawer);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        itemSelected(VIEW_NEWS);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_home_screen, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void itemSelected(int frag_id){

        switch (frag_id){
            case ADD_NEWS:
                Toast.makeText(getApplicationContext(),"Add news",Toast.LENGTH_SHORT).show();
                FragmentManager fm1 = getSupportFragmentManager();
                Fragment fragment1= new AddNewsFragment();
                FragmentTransaction transaction1 = fm1.beginTransaction();
                transaction1.replace(R.id.content_frame, fragment1).commit();
                break;
            case VIEW_NEWS:
                Toast.makeText(getApplicationContext(),"View news",Toast.LENGTH_SHORT).show();
                FragmentManager fm2 = getSupportFragmentManager();
                Fragment fragment2= new ViewNewsFragment();
                FragmentTransaction transaction2 = fm2.beginTransaction();
                transaction2.replace(R.id.content_frame, fragment2).commit();
                break;
            case LOG_OUT:
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(HomeScreen.this);
                alertDialog.setTitle("Confirm...");
                alertDialog.setMessage("Are you sure you want to Log Out?");
                alertDialog.setIcon(R.drawable.ic_alert);
                alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "Logging Out", Toast.LENGTH_SHORT).show();
                        Intent logOutIntent=new Intent(HomeScreen.this,MainActivity.class);
                        startActivity(logOutIntent);
                    }
                });

                alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to invoke NO event
                        Toast.makeText(getApplicationContext(), "Cancelling", Toast.LENGTH_SHORT).show();
                        dialog.cancel();
                    }
                });
                alertDialog.show();
                break;
        }
    }

    @Override
    public void onCommunicate(int id) {
        itemSelected(id);
    }

    @Override
    public void onNewsItemSelect(int location) {

        Toast.makeText(getApplicationContext(),"View news item",Toast.LENGTH_SHORT).show();
        FragmentManager fm3 = getSupportFragmentManager();
        Fragment fragment3= new NewsDetailsFragment();
        Bundle item=new Bundle();
        item.putInt("loc",location);
        fragment3.setArguments(item);
        FragmentTransaction transaction2 = fm3.beginTransaction();
        transaction2.replace(R.id.content_frame, fragment3).commit();
    }

    @Override
    public void changePic(int loc) {
        picValue=loc;
        Intent i = new Intent(
                Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(i, RESULT_LOAD_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            ImageView imageView=null ;
            if(picValue==PROF_PIC_CHANGE)
             imageView= (ImageView) findViewById(R.id.im_pic);
            else
                imageView= (ImageView) findViewById(R.id.im_nImage);

            imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));

        }


    }
}


