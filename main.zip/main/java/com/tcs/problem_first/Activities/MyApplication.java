package com.tcs.problem_first.Activities;

/**
 * Created by 983798 on 5/30/2016.
 */
import android.app.Application;

public class MyApplication extends Application{

    private static MyApplication sContext;
    public static MyApplication getContext() {
        return sContext;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sContext = this;
    }



}