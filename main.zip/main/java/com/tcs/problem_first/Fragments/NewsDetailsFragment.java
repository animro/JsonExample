package com.tcs.problem_first.Fragments;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.tcs.problem_first.R;
import com.tcs.problem_first.Utils.utils;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link NewsDetailsFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class NewsDetailsFragment extends Fragment {

    private OnFragmentInteractionListener mListener;
    AppCompatActivity homeActivity;
    Toolbar toolbar;
    int location;
    ImageView newsImage;
    TextView newsTitle;
    TextView newsCateg;
    TextView newsDesc;
    public NewsDetailsFragment() {
        // Required empty public constructor
    }

  @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_news_details, container, false);

        newsImage=(ImageView) v.findViewById(R.id.im_dImage);
        newsTitle=(TextView) v.findViewById(R.id.tv_dTitle);
        newsCateg=(TextView) v.findViewById(R.id.tv_dCateg);
        newsDesc=(TextView) v.findViewById(R.id.tv_dDesc);

        if(getArguments()!=null)
        {
            location=getArguments().getInt("loc");
            newsImage.setImageResource(utils.newsList.get(location).getnImage());
            newsTitle.setText(utils.newsList.get(location).getnTitle());
            newsCateg.setText(utils.newsList.get(location).getnCategory());
            newsDesc.setText(utils.newsList.get(location).getnDescription());
        }


        toolbar=(Toolbar)v.findViewById(R.id.toolbar);
        homeActivity.setSupportActionBar(toolbar);
        homeActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        homeActivity.getSupportActionBar().setDisplayShowHomeEnabled(true);
        homeActivity.getSupportActionBar().setTitle(R.string.my_app);

        return v;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        homeActivity=(AppCompatActivity)activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }

}
