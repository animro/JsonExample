package com.tcs.problem_first.Fragments;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.tcs.problem_first.MyCallBackInterface;
import com.tcs.problem_first.R;
import com.tcs.problem_first.Utils.news_elements;
import com.tcs.problem_first.Utils.utils;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link AddNewsFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class AddNewsFragment extends Fragment {

    Toolbar toolbar;
    AppCompatActivity homeActivity;
    MyCallBackInterface mContext;

    ImageView image;
    EditText title;
    EditText desc;
    Spinner categories;

    int img_val;
    String title_val;
    String desc_val;
    String catg_val;
    static final int NEWS_PIC_CHANGE=1;
    private OnFragmentInteractionListener mListener;


    public AddNewsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_add_news, container, false);
        setHasOptionsMenu(true);
        toolbar=(Toolbar)v.findViewById(R.id.toolbar);

        homeActivity.setSupportActionBar(toolbar);
        homeActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        homeActivity.getSupportActionBar().setDisplayShowHomeEnabled(true);
        homeActivity.getSupportActionBar().setTitle(R.string.add_news);

        image=(ImageView) v.findViewById(R.id.im_nImage);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.changePic(NEWS_PIC_CHANGE);            }
        });
        title=(EditText) v.findViewById(R.id.tv_nTitle);
        desc=(EditText) v.findViewById(R.id.tv_nDesc);
        categories=(Spinner)v.findViewById(R.id.spinner);

    return v;

    }


    @Override
    public void onCreateOptionsMenu(
            Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_add_news, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_svNews) {
            img_val=image.getId();
            title_val=title.getText().toString();
            desc_val=desc.getText().toString();
            catg_val=String.valueOf(categories.getSelectedItem());
            news_elements newsElement= new news_elements(img_val,title_val,desc_val,catg_val);
            utils.newsList.add(newsElement);
            Toast.makeText(homeActivity,"News Saved",Toast.LENGTH_SHORT);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        homeActivity=(AppCompatActivity)activity;
        mContext=(MyCallBackInterface)activity;

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

   // @Override
 /*   public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                homeActivity.onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }*/

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }

}
