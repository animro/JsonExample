package com.tcs.problem_first.Fragments;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.tcs.problem_first.Adapters.RowAdapter;
import com.tcs.problem_first.MyCallBackInterface;
import com.tcs.problem_first.R;
import com.tcs.problem_first.Utils.row_elements;
import com.tcs.problem_first.Utils.utils;


/**
 * A simple {@link Fragment} subclass.
 */
public class DrawerFragment extends Fragment {
    public static final int PROF_PIC_CHANGE=0;

    private MyCallBackInterface mContext;
    private Context actContext;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    ImageView profilePic;



    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.mContext=(MyCallBackInterface)activity;
        this.actContext=activity;
    }

    public DrawerFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.fragment_drawer, container, false);
        addToList();

        recyclerView=(RecyclerView)v.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(false);
        mLayoutManager=new LinearLayoutManager(actContext);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(new RowAdapter(mContext));

        profilePic=(ImageView)v.findViewById(R.id.im_pic);
        profilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.changePic(PROF_PIC_CHANGE);
            }
        });

        return v;
    }



    private void addToList() {
        if(utils.rowList.isEmpty()) {

            row_elements R1 = new row_elements(R.drawable.ic_add_news, "ADD NEWS");
            row_elements R2 = new row_elements(R.drawable.ic_view_news, "VIEW NEWS");
            row_elements R3 = new row_elements(R.drawable.ic_log_out, "LOG OUT");

            utils.rowList.add(R1);
            utils.rowList.add(R2);
            utils.rowList.add(R3);
        }
    }


}
