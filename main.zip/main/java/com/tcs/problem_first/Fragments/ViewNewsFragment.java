package com.tcs.problem_first.Fragments;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.tcs.problem_first.Adapters.NewsAdapter;
import com.tcs.problem_first.Adapters.RowAdapter;
import com.tcs.problem_first.MyCallBackInterface;
import com.tcs.problem_first.R;
import com.tcs.problem_first.Utils.news_elements;
import com.tcs.problem_first.Utils.utils;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ViewNewsFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class ViewNewsFragment extends Fragment {
    Toolbar toolbar;
    AppCompatActivity homeActivity;

    private OnFragmentInteractionListener mListener;
    private RecyclerView recyclerView;
    private LinearLayoutManager mLayoutManager;
    private MyCallBackInterface mContext;

    public ViewNewsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.fragment_view_news, container, false);

        addtoList();
        toolbar=(Toolbar)v.findViewById(R.id.toolbar);
        homeActivity.setSupportActionBar(toolbar);
        homeActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        homeActivity.getSupportActionBar().setDisplayShowHomeEnabled(true);
        homeActivity.getSupportActionBar().setTitle(R.string.my_app);

        recyclerView=(RecyclerView)v.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(false);
        mLayoutManager=new LinearLayoutManager(homeActivity);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(new NewsAdapter(mContext));

        return v;
    }

    private void addtoList() {
        if (utils.newsList.isEmpty()||utils.newsList.size()<5 ){

            news_elements N1= new news_elements(R.drawable.img_news1,"Attempted North Korea missile launch fails"," North Korea attempted to fire a missile from its east coast early on Tuesday but the launch appears to have failed, South Korean officials said, in what would be the latest in a string of unsuccessful ballistic missile tests by the isolated country.","International");
            news_elements N2= new news_elements(R.drawable.img_news2,"Batla House encounter: BJP protests over Sonia's statements","The Delhi unit of the Bharatiya Janata Party (BJP) staged a demonstration at the Indian National Congress headquarters here on Monday demanding that Sonia Gandhi apologise for calling the 2008 Batla House encounter “fake”.","National");
            news_elements N3= new news_elements(R.drawable.img_news3,"Protest against UGC notification","Teachers from various Delhi University colleges held a march from Mandi House to Parliament Street on Monday in protesting against the latest gazette notification of the University Grants Commission (UGC).","National");
            news_elements N4= new news_elements(R.drawable.img_news4,"David Warner: From a brat to a calm, mature leader","BENGALURU: Davey Warner, the protagonist of the Australian children's book series, 'The Kaboom Kid', lands in trouble more often than not.","Sports");
            news_elements N5= new news_elements(R.drawable.img_news5,"AR Rahman Receives Japan's Fukuoka Prize","Musician A R Rahman has an addition to his already vast collection of awards and honours. On Monday, he received Japan's Fukuoka Prize 2016 for his outstanding contribution to Asian culture through his music, news agency ANI reported.","Others");

            utils.newsList.add(N1);
            utils.newsList.add(N2);
            utils.newsList.add(N3);
            utils.newsList.add(N4);
            utils.newsList.add(N5);

        }

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
      homeActivity=(AppCompatActivity)activity;
        mContext=(MyCallBackInterface)activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }

}
