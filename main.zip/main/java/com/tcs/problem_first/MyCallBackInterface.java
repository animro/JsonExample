package com.tcs.problem_first;

/**
 * Created by 983798 on 5/30/2016.
 */
public interface MyCallBackInterface {
    public void onCommunicate(int id);
    public void onNewsItemSelect(int item);
    public void changePic(int loc);
}
