package com.tcs.problem_first.Utils;

/**
 * Created by 983798 on 5/30/2016.
 */
public class row_elements {


    private int rowId;
    private int rowImage;
    private String rowText;

    public row_elements(int rowId,int rowImage, String rowText) {
        this.rowImage = rowImage;
        this.rowText = rowText;
        this.rowId=rowId;
    }

    public row_elements(int rowImage, String rowText) {
        this.rowImage = rowImage;
        this.rowText = rowText;
    }

    public int getRowImage() {
        return rowImage;
    }

    public void setRowImage(int rowImage) {
        this.rowImage = rowImage;
    }

    public String getRowText() {
        return rowText;
    }

    public void setRowText(String rowText) {
        this.rowText = rowText;
    }
    public int getRowId() {
        return rowId;
    }

    public void setRowId(int rowId) {
        this.rowId = rowId;
    }

}
