package com.tcs.problem_first.Utils;

/**
 * Created by 983798 on 5/31/2016.
 */
public class news_elements {




    private int nImage;
    private String nTitle;
    private String nDescription;
    private String nCategory;


    public news_elements(int nImage, String nTitle, String nDescription, String nCategory) {
        this.nImage = nImage;
        this.nTitle = nTitle;
        this.nDescription = nDescription;
        this.nCategory = nCategory;
    }

    public int getnImage() {
        return nImage;
    }

    public void setnImage(int nImage) {
        this.nImage = nImage;
    }

    public String getnTitle() {
        return nTitle;
    }

    public void setnTitle(String nTitle) {
        this.nTitle = nTitle;
    }

    public String getnDescription() {
        return nDescription;
    }

    public void setnDescription(String nDescription) {
        this.nDescription = nDescription;
    }

    public String getnCategory() {
        return nCategory;
    }

    public void setnCategory(String nCategory) {
        this.nCategory = nCategory;
    }

}
