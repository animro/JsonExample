package com.tcs.problem_first.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 983798 on 5/30/2016.
 */
public class utils {

    public static List<row_elements> rowList = new ArrayList<>();
    public static List<news_elements> newsList=new ArrayList<>();
}
