package com.tcs.problem_first.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.tcs.problem_first.MyCallBackInterface;
import com.tcs.problem_first.R;
import com.tcs.problem_first.Utils.utils;

/**
 * Created by 983798 on 5/31/2016.
 */
public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {

    private static MyCallBackInterface mContext;
    public NewsAdapter(MyCallBackInterface context) {
        this.mContext=context;

    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView mNewsImage;
        private TextView mNewsText;

        public ViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position=getLayoutPosition();
                    mContext.onNewsItemSelect(position);
                }
            });
            mNewsImage = (ImageView) itemView.findViewById(R.id.im_news);
            mNewsText = (TextView) itemView.findViewById(R.id.tv_news);
        }

    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.news_list_layout, viewGroup, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
       //if(utils.newsList.get(position).getnCategory().equals("National")) {
           holder.mNewsText.setText(utils.newsList.get(position).getnTitle());
           holder.mNewsImage.setImageResource(utils.newsList.get(position).getnImage());

    }


    @Override
    public int getItemCount() {
        return utils.newsList.size();
    }

}
